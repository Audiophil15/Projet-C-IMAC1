#ifndef POS_H
#define POS_H

typedef struct {
	int x;
	int y;
} position_;

#endif