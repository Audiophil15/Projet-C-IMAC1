#include <iostream>
#include <cstring>

typedef struct {
	int y;
	char mtable[10];
} stable;

typedef struct {
	int x;
	char* pointeur;
} pointeur;

using namespace std;


int main(int argc, char const *argv[])
{
	pointeur objet1;
	objet1.x = 5;
	objet1.pointeur = (char*)malloc(15);
	strcpy(objet1.pointeur, "pointeur");

	stable s1, s2;
	printf("\ns::\n%p\n%p\n\n", s1.mtable, s2.mtable);
	s1.y = 12;
	strcpy(s1.mtable, "Arg");
	s2 = s1;
	printf("%p:%s, %d\n", s1.mtable, s1.mtable, s1.y);
	printf("%p:%s, %d\n", s2.mtable, s2.mtable, s2.y);

	pointeur p1, p2;
	printf("\np::\n%p\n%p\n\n", p1.pointeur, p2.pointeur);
	p1.x = 12;
	p1.pointeur = s1.mtable;
	p2 = p1;
	printf("%p:%s, %d\n", p1.pointeur, p1.pointeur, p1.x);
	printf("%p:%s, %d\n", p2.pointeur, p2.pointeur, p2.x);

	char** pointtab = (char**)malloc(sizeof(char*)*10);

	char tab[] = "123456789ABCDEF";

	stable* structab = (stable*)malloc(sizeof(stable)*10);
	cout << "\n" << structab << "-----" << endl;
	for (int i = 0; i < 10; i++){
		cout << &(structab[i]) << endl;
		structab[i].y = i;
		strcpy(structab[i].mtable, tab+i);
	}

	stable tmpstr;
	printf("\n\n%p\n", &tmpstr);
	for (int i = 0; i < 10; i++)
	{
		tmpstr = structab[i];
		pointtab[i] = tmpstr.mtable;
		printf("%p : %p : %p = %d\n", tmpstr.mtable, pointtab[i], structab[i].mtable, tmpstr.y);

	}
	

	std::cout << "\n\n================\n" << std::endl;
	for (int i = 0; i < 10; i++){
		std::cout << structab[i].mtable << std::endl;
	}
	std::cout << std::endl;
	
	for (int i = 0; i < 10; i++){
		std::cout << pointtab[i] << std::endl;
	}
	

	return 0;
}
